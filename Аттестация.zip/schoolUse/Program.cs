﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classSchool;



namespace schoolUse
{
    class Program
    {
        public static Class1 cls = new Class1();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();
            List<Students> students = new List<Students>
            {
                new Students(2019,819,"Дегтярева Маргарита Ивановна"),
                new Students(2018,818,"Румянцев Михаил Алексеевич"),
                new Students(2018,818,"Касьянов Кирилл Давидович"),
                new Students(2020,820,"Баранова Виктория Павловна"),
                new Students(2020,820,"Козлова Екатерина Давидовна"),
                new Students(2019,819,"Ежова Алиса Фёдоровна"),
                new Students(2021,821,"Сергеева Софья Ильинична"),
                new Students(2021,821,"Белова Ольга Даниэльевна"),
                new Students(2021,821,"Некрасов Артём Игоревич"),
                new Students(2018,818,"Аникина Полина Игоревна")
            };
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.02.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.03.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.04.2022"), students));

            foreach(Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.student.fio}");
            }
            Console.WriteLine();
            foreach (var keyValuePair in cls.GetCountDisease(marks))
            {
                Console.WriteLine($"{keyValuePair.Key} - {keyValuePair.Value}");

            }
            Console.WriteLine();
            foreach (var keyValuePair in cls.GetCountTruancy(marks))
            {
                Console.WriteLine($"{keyValuePair.Key} - {keyValuePair.Value}");
            }
            Console.WriteLine();
            foreach(Students std in students)
            {
                Console.WriteLine(cls.GetStudNumber(std.year, std.group, std.fio));
            }
            Console.WriteLine();
            Console.WriteLine(cls.MinAVG(new string[6]{ "3","4","5","б","п","н"}));
            Console.ReadKey();

        }
    }
}
